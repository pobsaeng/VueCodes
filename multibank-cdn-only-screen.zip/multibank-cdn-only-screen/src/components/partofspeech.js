Vue.component("partofspeech", {
  template: `
  <div class="row">
    <div class="col-md-12">
        
      </div>
    </div>
  </div>
  `,
  data: function() {
    return {};
  },
  methods: {},
  mounted() {
    console.log("mounted!");
  }
});
