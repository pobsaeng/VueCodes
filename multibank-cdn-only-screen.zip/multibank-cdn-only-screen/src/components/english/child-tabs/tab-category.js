Vue.component("tab-category", {
    template: `
    <form role="form-horizontal">
      <!-- text input -->
      <div class="form-group">
        <label>Name:</label>
        <input type="text" class="form-control" placeholder="...">
      </div>

      <!-- textarea -->
      <div class="form-group">
        <label>Remark:</label>
        <textarea class="form-control" rows="3" placeholder="..."></textarea>
      </div>

      <div class="box-footer">
        <button type="submit" class="btn btn-info">Save</button>
        <button type="submit" class="btn btn-warning">Cancel</button>
      </div>

    </form>
    `,
    data: function() {
      return {};
    },
    methods: {},
    mounted() {
      console.log("mounted!");
    }
  });
  