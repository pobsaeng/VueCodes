Vue.component("tab-partofspeech", {
    template: `
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Part of speech</h3>
      </div>
      <div class="box-body">
        <form role="form">

          <div class="form-group has-success">
            <label class="control-label" for="inputSuccess">Name</label>
            <input type="text" class="form-control" id="inputSuccess" placeholder="Enter ...">
          </div>

          <div class="form-group has-warning">
            <label class="control-label" for="inputWarning">Meaning</label>
            <input type="text" class="form-control" id="inputWarning" placeholder="Enter ...">
          </div>

          <div class="form-group">
            <label>Hot to use.</label>
            <textarea class="form-control" rows="3" placeholder="Enter ..."></textarea>
          </div>

          <div class="form-group">
            <label>Note</label>
            <textarea class="form-control" rows="3" placeholder="Enter ..."></textarea>
          </div>

          <div class="pull-right">
            <button type="button" class="btn bg-navy">Save</button>
            <button type="button" class="btn bg-purple">Cancel</button>
          </div>

        </form>
      </div>
    </div>
    `,
    data: function() {
      return {};
    },
    methods: {},
    mounted() {
      console.log("mounted!");
    }
  });
  