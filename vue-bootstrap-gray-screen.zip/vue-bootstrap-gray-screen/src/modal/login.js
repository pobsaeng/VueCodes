Vue.component('login-modal', {
    template: `
    <div v-if="showModal" @close="showModal = false">
    <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="loginmodal-container">
            <login></login>
        </div>
    </div>
    </div>
    </div>
  `,
    data: function () {
        return {
            showModal: false
        }
    },
    mounted() {
        this.showModaln  = true;
    }
})