Vue.component("home", {
  template: `
  <div>
    <div><a href="#" data-toggle="modal" data-target="#login-modal">Login</a></div>
    <login-modal></login-modal>
  
    <button type="button" data-toggle="modal" data-target="#confirm-modal">Small Message</button>
    <alert-modal :head="'Alert Message'" 
    :msg="'dfdffdf'"></alert-modal>

    </div>
  `,
  data: function() {
    return {
      showModal: false
    };
  },
  methods: {},
  mounted() {
    console.log("mounted!");
  }
});
