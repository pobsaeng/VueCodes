Vue.component("tab-word", {
    template: `
    <!-- settings tab-pane -->
    <form class="form-horizontal">
      <div class="form-group">
        <label for="inputName" class="col-sm-2 control-label">Category</label>
        <div class="col-sm-10">
          <select class="form-control">
            <option>option 1</option>
            <option>option 2</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label for="inputName" class="col-sm-2 control-label">Word name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="inputName" placeholder="...">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-2 control-label">Meaning</label>

        <div class="col-sm-10">
          <input type="text" class="form-control" placeholder="...">
        </div>
      </div>
      <div class="form-group">
        <label for="inputName" class="col-sm-2 control-label">Hot to use it.</label>

        <div class="col-sm-10">
          <textarea class="form-control" placeholder="..."></textarea>
        </div>
      </div>
      <div class="form-group">
        <label for="inputExperience" class="col-sm-2 control-label">Note</label>

        <div class="col-sm-10">
          <textarea class="form-control" id="inputExperience" placeholder="..."></textarea>
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn bg-olive btn-width">Save</button>
          <button type="submit" class="btn bg-orange btn-width">Cancel</button>
        </div>
      </div>
    </form>
    `,
    data: function() {
      return {};
    },
    methods: {},
    mounted() {
      console.log("mounted!");
    }
  });
  