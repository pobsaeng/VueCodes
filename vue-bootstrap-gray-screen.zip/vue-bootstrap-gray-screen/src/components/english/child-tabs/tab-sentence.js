Vue.component("tab-sentence", {
    template: `
    <!-- settings tab-pane -->
    <form class="form-horizontal">
      <div class="form-group">
        <label for="inputName" class="col-sm-2 control-label">Word</label>
        <div class="col-sm-10">
          <select class="form-control">
            <option>option 1</option>
            <option>option 2</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label for="inputName" class="col-sm-2 control-label">Example.</label>

        <div class="col-sm-10">
          <textarea class="form-control" rows="4" placeholder="..."></textarea>
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn bg-purple btn-width">Save</button>
          <button type="submit" class="btn bg-maroon btn-width">Cancel</button>
        </div>
      </div>
    </form>
    `,
    data: function() {
      return {};
    },
    methods: {},
    mounted() {
      console.log("mounted!");
    }
  });
  