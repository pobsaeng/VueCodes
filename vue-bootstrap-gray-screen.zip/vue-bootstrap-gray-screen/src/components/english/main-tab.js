Vue.component("main-tab", {
  template: `
  <div class="row">
    <div class="col-md-12">
    
      <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
          <li><a href="#category" data-toggle="tab">Category</a></li>
          <li class="active"><a href="#word" data-toggle="tab">Word</a></li>
          <li><a href="#sentence" data-toggle="tab">Sentence</a></li>
        </ul>

        <div class="tab-content">

          <!-- Category tab-pane -->
          <div class="tab-pane" id="category">
            <tab-category></tab-category>
          </div>

          <!-- Word tab-pane -->
          <div class="active tab-pane" id="word">
            <tab-word></tab-word>
          </div>

          <!-- Sentence tab-pane -->
          <div class="tab-pane" id="sentence">
            <tab-sentence></tab-sentence>
          </div>

        </div>

      </div>

    </div>
  </div> 
  `,
  data: function() {
    return {};
  },
  methods: {},
  mounted() {
    console.log("mounted!");
  }
});
