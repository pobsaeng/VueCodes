Vue.component('side-bar', {
    template: `
    <div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li class="sidebar-search">
                <div class="input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search..">
                    <span class="input-group-btn">
                        <button class="btn btn-default" type="button">
                            <i class="fa fa-search"></i>
                        </button>
                    </span>
                </div>
            </li>

            <li>
                <a href="#"><i class="fa fa-home fa-fw"></i> Home</a>
            </li>

            <li>
                <a href="#"><i class="fa fa-user fa-fw"></i>
                Users <span class="fa arrow"></span>
                </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="#">Flot Charts</a>
                    </li>
                    <li>
                        <a href="#">Morris.js Charts</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="#">
                    <i class="fa fa-bars fa-fw"></i> UI
                    <span class="fa arrow"></span>
                </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="#">Panels and Wells</a>
                    </li>
                    <li>
                        <a href="#">Buttons</a>
                    </li>
                    <li>
                        <a href="#">Notifications</a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
    </div>
    <!-- /.navbar-static-side -->
  `,
    mounted() {
        setTimeout(function () {}, 1000);

        // axios({
        //     method: 'get',
        //     url: "http://10.100.60.84:8529/BookAPI/find/all/books"
        // }).then(function (response) {
        //     console.log(response.data);

        // }).catch(error => {
        //     console.log(error.response.data);
        // });


    }
})
