Vue.component('nav-top', {
    template: `
    <ul class="nav navbar-top-links navbar-right">
    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <i class="fa fa-envelope fa-fw"></i>
            <i class="fa fa-caret-down"></i>
        </a>
    </li>
    <!-- /.dropdown -->
    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <i class="fa fa-tasks fa-fw"></i>
            <i class="fa fa-caret-down"></i>
        </a>
    </li>
    <!-- /.dropdown -->
    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <i class="fa fa-bell fa-fw"></i>
            <i class="fa fa-caret-down"></i>
        </a>
    </li>
    <!-- /.dropdown -->
    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <i class="fa fa-user fa-fw"></i>
            <i class="fa fa-caret-down"></i>
        </a>
    </li>
    <!-- /.dropdown -->
    </ul>
    <!-- /.navbar-top-links -->
  `,
    mounted() {
        setTimeout(function () { }, 1000);

        // axios({
        //     method: 'get',
        //     url: "http://10.100.60.84:8529/BookAPI/find/all/books"
        // }).then(function (response) {
        //     console.log(response.data);

        // }).catch(error => {
        //     console.log(error.response.data);
        // });


    }
})
